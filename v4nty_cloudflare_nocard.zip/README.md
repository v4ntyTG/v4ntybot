# V4nty | Бот — Cloudflare версия

## Схема

- GitHub Pages — `index.html`
- Cloudflare Worker — API
- Cloudflare D1 — публикации и метаданные
- Cloudflare R2 — обложки и изображения внутри постов
- Termux после переноса не нужен для работы сайта

## 1. Установить Node.js и Wrangler

На ПК:

```bash
npm install
npx wrangler login
```

## 2. Создать D1

```bash
npx wrangler d1 create v4nty-db
```

Скопируй `database_id` из ответа и вставь его вместо `REPLACE_WITH_D1_DATABASE_ID` в `wrangler.toml`.

Затем:

```bash
npx wrangler d1 execute v4nty-db --remote --file=schema.sql
```

## 3. Создать R2

```bash
npx wrangler r2 bucket create v4nty-media
```

## 4. Секреты Worker

```bash
npx wrangler secret put ADMIN_LOGIN
npx wrangler secret put ADMIN_PASSWORD
npx wrangler secret put SESSION_SECRET
```

Используй длинные уникальные значения. Секреты не добавляй в GitHub.

## 5. Настроить CORS

В `wrangler.toml` замени:

```toml
FRONTEND_ORIGIN = "https://YOUR-USERNAME.github.io"
```

на реальный адрес GitHub Pages.

## 6. Установить зависимости и проверить

```bash
npm install
npm run check
```

## 7. Первый запуск Worker

```bash
npx wrangler deploy
```

В ответ получишь адрес вида:

```text
https://v4nty-site-api.<твой-аккаунт>.workers.dev
```

В `index.html` замени `API_URL` на этот адрес.

## 8. GitHub Pages

Положи `index.html` в репозиторий и включи:

Settings → Pages → Deploy from branch → `main` → `/ (root)`.

## 9. Перенос старой базы

Старый сервер должен иметь:

```text
data/v4nty.sqlite
uploads/
```

Положи `migrate.mjs` в папку проекта со старой базой и выполни:

```bash
node migrate.mjs
```

Появится `migration.sql`.

Загрузи данные:

```bash
npx wrangler d1 execute v4nty-db --remote --file=migration.sql
```

Старые картинки загружай в R2 с теми же именами объектов:

```text
covers/ИМЯ_ФАЙЛА
```

Например:

```bash
npx wrangler r2 object put v4nty-media/covers/123-example.jpg --file=uploads/123-example.jpg
```

После миграции старые файлы `data/v4nty.sqlite` и `uploads/` не удаляй, пока не убедишься, что всё открывается.

## 10. Новые возможности

### Форматы

В редакторе доступны:

- жирный, курсив, подчёркивание, зачёркивание;
- выделение, маленький/верхний/нижний индекс;
- заголовки H2/H3;
- обычный абзац;
- маркированный и нумерованный список;
- inline code и code block;
- цитата;
- spoiler;
- ссылка;
- горизонтальная линия.

### Изображения

- отдельная обложка поста;
- подпись обложки;
- несколько изображений внутри поста;
- отдельная краткая подпись к каждому изображению;
- изображения внутри текста можно вставлять в нужное место;
- изображения физически лежат в R2.

### Тема

Кнопка в шапке переключает:

- светлую тему;
- тёмную тему.

Выбор сохраняется в `localStorage`, поэтому после перезагрузки страницы тема остаётся.
