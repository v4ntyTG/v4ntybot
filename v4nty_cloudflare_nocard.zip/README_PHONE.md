# V4nty | Бот — Cloudflare D1 + GitHub media + GitHub Actions

## Идея

- GitHub Pages: `index.html`
- Cloudflare Worker: API, админка, авторизация
- Cloudflare D1: публикации и метаданные
- GitHub repository: фотографии
- GitHub Actions: развёртывание Worker с телефона

R2 не используется, поэтому для этой схемы не нужен платёжный метод R2.

## Что нужно создать

1. Cloudflare D1: `v4nty-db`
2. Публичный GitHub repository для сайта/медиа
3. GitHub fine-grained token с `Contents: Read and write` только для этого репозитория
4. GitHub Actions secrets:
   - `CLOUDFLARE_API_TOKEN`
   - `CLOUDFLARE_ACCOUNT_ID`
   - `ADMIN_LOGIN`
   - `ADMIN_PASSWORD`
   - `SESSION_SECRET`
   - `GITHUB_TOKEN`

## wrangler.toml

Заполни:

- `database_id` — полный D1 Database ID
- `FRONTEND_ORIGIN` — только origin GitHub Pages, например `https://name.github.io`
- `GITHUB_OWNER` — владелец репозитория
- `GITHUB_REPO` — название репозитория

Фотографии складываются в `media/` репозитория и становятся доступны через `raw.githubusercontent.com`.

## GitHub token

Создай fine-grained PAT для нужного репозитория и выдай только:

- Contents → Read and write

Токен никогда не добавляй в `index.html` или обычный файл репозитория. Добавь его как Secret `GITHUB_TOKEN` в GitHub Actions. Для Worker секрет также должен попасть в Cloudflare Worker secrets через workflow.

## Deploy

GitHub Actions workflow разворачивает Worker и применяет `schema.sql`.

Для первого deploy добавь secrets и запусти workflow вручную.

## Важно про картинки

Репозиторий с фотографиями должен быть публичным, иначе браузер посетителя не сможет получать `raw.githubusercontent.com` напрямую без авторизации.

## Функции index.html

- светлая/тёмная тема с сохранением выбора
- обложка поста + подпись
- изображения внутри поста + подписи
- вставка изображения в позицию курсора
- B/I/U/S
- mark/small/sub/sup
- h2/h3
- списки
- code/pre
- quote/spoiler/link/hr
- черновики
- поиск
- админка
